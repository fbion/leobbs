<?php
//===================================
//         ������������Ȩ����
// ������ҳ:   http://www.gouhuo.com
// vBulletin:  http://bbs.ruian.com
// LB5000II:   http://www.cnirc.org
//===================================
	$id=mysql_connect('localhost','root','');			// MySQl �����������û�������
	$db=mysql_select_db('vbulletin',$id);				// ���ݿ���
	$lb_cgi_path = "/path/to/cgi-bin/lb5000";			// LB5000 CGI Ŀ¼(leoboard.cgi����Ŀ¼)�ľ���·��
//======== ������� =================
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>vBulletin 2.0x �� LB5000II - ��̳ת��</title>
</head>
<body bgcolor="#FFFFFF">
<?php
	echo "<b>----- �Ѵ��ڵ�LB5000II��̳ -----</b><br>\n";
	$max_exists_cate_id = 0;
	$max_exists_forum_id = 0;
	$exists_forums = readtxt("$lb_cgi_path/data/allforums.cgi");
	$lines = explode("\n", $exists_forums);
	while (list($key, $val) = each($lines)) {
		$temp = explode("\t", $val);
		if ($max_exists_cate_id < $temp[2]) {
			$max_exists_cate_id = $temp[2];
		}
		if ($max_exists_forum_id < $temp[0]) {
			$max_exists_forum_id = $temp[0];
		}
		if ($temp[3]) {
			echo "$temp[0]. $temp[1]($temp[2]) : $temp[3]($temp[0])<br>\n";
		}
	}
	echo "��������: $max_exists_cate_id / �����̳���: $max_exists_forum_id\n";
	echo "<hr>\n";

	echo "<b>----- vBulletin �ķ��� -----</b><br>\n";
	$sqldo="select forumid,title,parentid from forum where parentid=-1";
	$result=mysql_query($sqldo);
	if($result){
		$cate_id_new=$max_exists_cate_id+1;
		while($myrow=mysql_fetch_array($result)){
			$i = $myrow[forumid];
			$allcategorys[$i] = $myrow[title];
			$cate_id_dict[$i] = $cate_id_new;
			echo "$i -> $cate_id_new : $myrow[title]<br>\n";
			$cate_id_new++;
		}
	}
	echo "<hr>\n";

	echo "<b>----- vBulletin ����̳ -----</b><br>\n";
	$sqldo="select * from forum where parentid!=-1";
	$result=mysql_query($sqldo);
	if($result){
		$forum_id_new=$max_exists_forum_id + 1;
		$forumfp = fopen("$lb_cgi_path/data/allforums.cgi", "a");
		while($myrow=mysql_fetch_array($result)){
			$i = $myrow[forumid];
			$cid = $myrow[parentid];
			$description = str_replace("\n", '', $myrow[description]);
			$forum_id_dict[$i] = $forum_id_new;
			echo "$i -> $forum_id_new : \t$allcategorys[$cid]($cid -> $cate_id_dict[$cid])\t$myrow[title]($myrow[forumid])<br>\n";
			$new_forum_line = "$forum_id_new\t$allcategorys[$cid]\t$cate_id_dict[$cid]\t$myrow[title]\t$description\t\toff	on	no	yes			0	0	logo.gif				no	yes		http://						\n";
			mkdir("$lb_cgi_path/forum$forum_id_new", 0755);
			writetxt("$lb_cgi_path/forum$forum_id_new/index.html", '-');
			writetxt("$lb_cgi_path/forum$forum_id_new/list.cgi", '');
			writetxt("$lb_cgi_path/forum$forum_id_new/foruminfo.cgi", $new_forum_line);
			fwrite($forumfp, $mylines);
			$forum_id_new++;
		}
		fclose($forumfp);
	}

	$sqldo="select threadid,forumid from thread order by dateline";
	$result=mysql_query($sqldo);
	if($result){
		while($myrow=mysql_fetch_array($result)){
			$mythreadid = $myrow[threadid];
			$threadid2forumid[$mythreadid] = $myrow[forumid];
		}
	}

	$sqldo="select * from post order by dateline";
	$result=mysql_query($sqldo);
	if($result){
		while($myrow=mysql_fetch_array($result)){
			$mythreadid = $myrow[threadid];
			$myforumid_old = $threadid2forumid[$mythreadid];
			$myforumid = $forum_id_dict[$myforumid_old];
			$pagetext = $myrow[pagetext];
//			$pagetext = nl2br($myrow[pagetext]);
//			$pagetext = str_replace("\r", '<br>', $pagetext);
			$pagetext = str_replace("\n", '<br>', $pagetext);
			$pagetext = str_replace('<br />', '<br>', $pagetext);
			$thd_line = "$myrow[username]\t$myrow[title]\t$myrow[ipaddress]=\tyes\tyes\t$myrow[dateline]\t$pagetext\t\t\n";
			$thd_file = "$lb_cgi_path/forum$myforumid/$mythreadid.thd.cgi";
			if (file_exists($thd_file)) {
				$fp = fopen($thd_file, "a");
			}
			else {
				$fp = fopen($thd_file, "w");
			}
			fwrite($fp, $thd_line);
			fclose($fp);
		}
	}

////////////////////////////////////
function readtxt ($txtfile) {
	$mylines="";
	if (file_exists($txtfile)) {
		$fp = fopen($txtfile, "r");
		while ($temp = fgets($fp, 4096)) {
			$mylines.=$temp;
		}
		fclose($fp);
	}
	return $mylines;
}

function writetxt ($txtfile,$mylines) {
	$myfp = fopen($txtfile, "w");
	fwrite($myfp, $mylines);
	fclose($myfp);
}
?>
</body>
</html>
