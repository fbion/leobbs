<?php
//===================================
//         ������������Ȩ����
// ������ҳ:   http://www.gouhuo.com
// vBulletin:  http://bbs.ruian.com
// LB5000II:   http://www.cnirc.org
//===================================
	$id=mysql_connect('localhost','root','');				// MySQl �����������û�������
	$db=mysql_select_db('vbulletin',$id);					// ���ݿ���
	$lb_member_path = "/path/to/cgi-bin/lb5000/members";	// LB5000 �û���������Ŀ¼�ľ���·��
//======== ������� =================
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>vBulletin 2.0x �� LB5000II - �û�ת��</title>
</head>
<body bgcolor="#FFFFFF">
<?php
	$numok=0;
	$numerr=0;
	$sqldo="select * from user";
	$result=mysql_query($sqldo);
	if($result){
		while($myrow=mysql_fetch_array($result)){
			$membername = trim(htmlspecialchars($myrow[username]));
			$membername = strtr($membername, ' ', '_');
			$membername = strtolower($membername);
			$password = $myrow[password];
			$membertitle = "Member";
			switch($myrow[usergroupid]) {
				case 2:
					$membercode = "me";
					break;
				case 5:
					$membercode = "smo";
					break;
				case 6:
					$membercode = "ad";
					break;
				case 7:
					$membercode = "mo";
					break;
				default:
					$membercode = "banned";
					break;
			}
			$numberofposts = $myrow[posts];
			$emailaddress = $myrow[email];
			$myrow[showemail] ? $showemail = "yes" : $showemail = "no";
			$ipaddress = $myrow[ipaddress];
			$homepage = $myrow[homepage];
			$aolname = $myrow[oicq];
			$icqnumber = $myrow[icq];
			$location = "";
			$interests = "";
			$joineddate = $myrow[joindate];
			$lastpostdate = $myrow[lastpost];
			$signature = htmlspecialchars($myrow[signature]);
			$timedifference = "";
			$privateforums = "";
			$useravatar = "";
			$userflag = "";
			$userxz = "";
			$misc3 = "";
			$personalavatar = "";
			$personalwidth = "";
			$personalheight = "";
			$rating = "";
			$lastgone = $myrow[lastvisit];
			$visitno = "";
			$addjy = "";
			$meili = "";
			$mymoney = "";
			$postdel = "";
			$sex = "";
			$education = "";
			$marry = "";
			$work = "";
			$born = strtr($myrow[birthday], '-', '/');
			$useradd1 = "";
			$useradd2 = "";
			$jhmp = "";
			$useradd3 = "";
			$useradd4 = "";
			$useradd5 = "";
			$useradd6 = "";
			$useradd7 = "";
			$useradd8 = "";

			$userfile = "$lb_member_path/$membername.cgi";
			if (eregi("^[\`\~\!\@\#\$\%\^\&\*\(\)\=\+\\\{\}\;\'\:\"\,\.\/\<\>\?]",$membername)) {
				echo "<font color=\"#FF0000\">$membername �Ƿ��û���������ת����</font><br>\n";
				$numerr++;
			}
			elseif (file_exists($userfile)) {
				echo "$membername �û��Ѵ��ڣ�����ת����<br>\n";
				$numerr++;
			}
			else {
				$myfp = fopen($userfile, "w");
				if ($myfp) {
					$userline = "$membername\t$password\t$membertitle\t$membercode\t$numberofposts\t$emailaddress\t$showemail\t$ipaddress\t$homepage\t$aolname\t$icqnumber\t$location\t$interests\t$joineddate\t$lastpostdate\t$signature\t$timedifference\t$privateforums\t$useravatar\t$userflag\t$userxz\t$misc3\t$personalavatar\t$personalwidth\t$personalheight\t$rating\t$lastgone\t$visitno\t$addjy\t$meili\t$mymoney\t$postdel\t$sex\t$education\t$marry\t$work\t$born\t$useradd1\t$useradd2\t$jhmp\t$useradd3\t$useradd4\t$useradd5\t$useradd6\t$useradd7\t$useradd8\t";
					fwrite($myfp, $userline);
					fclose($myfp);
					$numok++;
				}
				else {
					echo "$userfile д��ʧ�ܣ�����·����Ȩ�ޣ�ת����ֹ��<br>\n";
					break;
				}
			}
		}
	}
	echo "<br>ת������� �ɹ���$numok / ʧ�ܣ�$numerr<br>\n";
?>
</body>
</html>
